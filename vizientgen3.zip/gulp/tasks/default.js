var gulp = require('gulp-help')(require('gulp'));

gulp.task('default', false, ['help']);